# LOST HOSTING — Render deploy guide

A Flask-based Python bot hosting panel.

## What was fixed for production
- Added `psutil` (was imported but missing from requirements) and `gunicorn`.
- `debug=True` -> `debug=False` (the Werkzeug debugger is a remote-code-execution
  risk if exposed publicly).
- Port now read from `$PORT` (Render injects this) with a 5000 fallback.
- `SECRET_KEY` now read from an environment variable.

## Deploy on Render

### Option 1 — Blueprint (render.yaml)
1. Push this folder to a GitHub repo.
2. Render dashboard -> New -> Blueprint -> pick the repo.
3. Render reads `render.yaml`, builds and deploys automatically.

### Option 2 — Manual Web Service
1. Push this folder to GitHub.
2. Render -> New -> Web Service -> connect the repo.
3. Settings:
   - Environment: Python
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `gunicorn --workers 1 --threads 8 --bind 0.0.0.0:$PORT app:app`
4. Add env var `SECRET_KEY` (Generate). Optionally `PYTHON_VERSION = 3.12.6`.
5. Deploy.

## Important notes

- **Run ONE worker.** The panel tracks bots and spawns child processes in-process;
  multiple gunicorn workers would each manage a separate set and break behaviour.
  `--threads 8` gives concurrency within a single worker.
- **Persistent storage.** The app writes `users.json` and the `bots/` folder to
  disk. On Render's free plan the filesystem is EPHEMERAL — all users and bots
  are lost on every restart/redeploy. For real use, add a Render Disk (paid
  plans) and point `USERS_FILE` / `BOTS_DIR` at the mount path, e.g.:
      USERS_FILE = '/var/data/users.json'
      BOTS_DIR   = '/var/data/bots'
  and add to render.yaml:
      disk:
        name: data
        mountPath: /var/data
        sizeGB: 1
- **Spin-down.** Free web services sleep after ~15 min without traffic; when the
  service sleeps, any hosted bots stop. Use a paid instance (or a keep-alive
  ping) if bots must run continuously.
- **Change the default admin password.** Default login is `admin` / `admin123`.
  Change it before exposing the panel publicly.
- **Hosted bots share this container.** Every bot runs as a child process of the
  web service, using the same CPU/RAM. There is no per-bot isolation.

## Run locally
    pip install -r requirements.txt
    python app.py
    # http://localhost:5000  (admin / admin123)

---

## If Render gives: "dockerfile parse error ... unknown instruction: PK\x03\x04"

That error means the file named `Dockerfile` in your repo is actually the ZIP
archive (PK is the ZIP magic number), not a text Dockerfile.

Fixes:
- **Easiest:** don't use Docker. In Render set Environment = **Python** and use
  the start command `gunicorn --workers 1 --threads 8 --bind 0.0.0.0:$PORT app:app`.
  Delete any stray `Dockerfile` from the repo.
- **Or use Docker properly:** replace the bad file with the real text `Dockerfile`
  included in this bundle (Render -> Environment = Docker). Make sure you commit
  the *text* Dockerfile, not a renamed .zip.

## Deploy with Docker on Render
1. Repo root must contain the real `Dockerfile` (text, from this bundle).
2. Render -> New -> Web Service -> Environment = **Docker**.
3. Render builds the image and runs it. Set `SECRET_KEY` env var.
